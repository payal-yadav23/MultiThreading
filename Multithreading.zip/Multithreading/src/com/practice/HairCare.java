package com.practice;

public class HairCare implements Runnable {

	@Override
	public void run() {

		System.out.print("2. HAIR CARE PRODUCTS :=");
		System.out.println("1.Shampoo " + "\n\t\t\t 2.Hair Serum" + "\n\t\t\t 3.Conditioner" + "\n\t\t\t 4.Mask"
				+ "\n\t\t\t 5.Hair Color");

		System.out.println("-----------------------------------------------------------------------------------");

	}

}
