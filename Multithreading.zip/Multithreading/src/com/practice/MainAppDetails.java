package com.practice;

public class MainAppDetails {

	public static void main(String[] args) {
		NykaaGlow ng = new NykaaGlow();
		ng.GlowUp();
	}
	
}
